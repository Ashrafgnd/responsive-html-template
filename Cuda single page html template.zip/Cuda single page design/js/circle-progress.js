(function($){

    $.fn.progressAnimate   =   function(opts){
       
        defaults = {
            min : 0,
            max : 100,
            dataTo : 90,
            radius : 50,
            fontColor: "#2f2f2f",
            thickness : 15,
            circleBackground: "transparent",
            circleBgColor : "green",
            circleFgColor : "purple",
            duration: 30,
            lineCap: "round", // butt,round,square => *butt is default*
			fontSize: "36px tahoma" // declare the font size and face
        };
        var options = $.extend({},defaults,opts);
        var box = Math.PI*options.radius;
        var html = "<canvas id=\"cnv_circle\" height="+ box +" width="+ box +"></canvas>"+"<canvas id=\"cnv_circle\" height="+ box +" width="+ box +"></canvas>";
        this.append(html);

        var radiusVal, thicknessVal,minVal,maxVal,dataToVal,fontColorVal,circleBgColorVal,circleFgColorVal,durationVal,lineCapVal,fontSizeVal,bgCircleVal,diff;
        
        
        radiusVal = options.radius;
        thicknessVal = options.thickness;
        minVal = options.min;
        maxVal = options.max;
        dataToVal = options.dataTo;
        fontColorVal = options.fontColor;
        fontSizeVal = options.fontSize;
        circleBgColorVal = options.circleBgColor;
        circleFgColorVal = options.circleFgColor;
        durationVal = options.duration;
        lineCapVal = options.lineCap;
        bgCircleVal = options.circleBackground;




        var ctx = $(this).children("#cnv_circle");
        var circleBg = $(ctx)[0].getContext("2d");
        var circleFg = $(ctx)[1].getContext("2d");
        var startPoint = Math.PI*1.5;
        var endPoint = Math.PI*2;
        var cnvWidth = circleBg.canvas.width;
        var cnvHeight = circleFg.canvas.height;
        
        // progressCircleBg is the background circle color and others style
        function progressCircleBg(){
            circleBg.lineWidth = thicknessVal;
            circleBg.strokeStyle = circleBgColorVal;
            circleBg.fillStyle = bgCircleVal;
            circleBg.fillRect(0,0,cnvWidth,cnvHeight);
            circleBg.fill();
            circleBg.beginPath();
            circleBg.arc(cnvWidth/2,cnvHeight/2,radiusVal,startPoint,endPoint+startPoint);
            circleBg.stroke();
        }
        progressCircleBg();

        function progressCircleFg(){
            diff = ((minVal/maxVal)*2*Math.PI);
            circleFg.clearRect(0,0,cnvWidth,cnvHeight);
            circleFg.strokeStyle = circleFgColorVal;
            circleFg.fillStyle = fontColorVal;
            circleFg.font = fontSizeVal;
            circleFg.lineWidth = thicknessVal;
            circleFg.fillText(minVal + '%', cnvWidth/2+10,cnvHeight/2+10);
            circleFg.textAlign = "center";
            circleFg.lineCap = lineCapVal;
            circleFg.beginPath();
            circleFg.arc(cnvWidth/2,cnvHeight/2,radiusVal,startPoint,diff+startPoint);
            circleFg.stroke();
            if(minVal>=dataToVal){
                clearInterval(fgAnimation);
            }
            minVal++;
        }
        var fgAnimation = setInterval(progressCircleFg,durationVal);
        
    }

})(jQuery);