jQuery(document).ready(function(){

	// Border effect in around button
	jQuery("button a").append("<span></span><span></span><span></span><span></span>");


	//Sticky menu fixed top
	jQuery(window).scroll(function(){
		var scrollHeight = jQuery(window).scrollTop();
		if(scrollHeight >= 120){
			jQuery(".sticky-menu").css("position","fixed");
			jQuery(".sticky-menu").css("top","0");
			jQuery(".sticky-menu").css("background","#17c2a4");
			jQuery(".sticky-menu").css("z-index", "9999");
		}
		else if(scrollHeight<=120){
			jQuery(".sticky-menu").css("background","transparent");
		}
	});
	//Responsive menu showing
	jQuery(".responsive-menu-icon a").on("click",function(){
		jQuery(".main-menu-width").slideToggle();

		return false;
	})
	$(window).scroll(function(){
		if($(window).scrollTop()>=$(".services-margin").offset().top-windowHeight){
			$(".services-margin.animated").addClass("fadeInRight delay-1s");
		}
		else{
			$(".services-margin.animated").removeClass("fadeInRight");
		}
	});

	// Progress circle section
	progressStart = true;
	
	var windowHeight = $(window).height();
	var skillHeight = $(".progress-circle-bar").offset().top- windowHeight;
	
	$(window).scroll(function(){
		if($(window).scrollTop() >= skillHeight){
			if(progressStart == true){
				$(".skill-progress1").progressAnimate({
					radius: 90,
					duration: 40,
					dataTo: 90,
					thickness: 14,
					circleBgColor : "#DFE8ED",
					circleFgColor : "#30BAE8",
					lineCap: "butt",
					fontColor: "#FFFFFF",
					fontSize: "40px Titillium Web"
				});
				$(".skill-progress2").progressAnimate({
					radius: 90,
					duration: 40,
					dataTo: 75,
					thickness: 14,
					circleBgColor : "#DFE8ED",
					circleFgColor : "#D74681",
					lineCap: "butt",
					fontColor: "#FFFFFF",
					fontSize: "40px Titillium Web"
				});
				$(".skill-progress3").progressAnimate({
					radius: 90,
					duration: 40,
					dataTo: 70,
					thickness: 14,
					circleBgColor : "#DFE8ED",
					circleFgColor : "#15C6A9",
					lineCap: "butt",
					fontColor: "#FFFFFF",
					fontSize: "40px Titillium Web"
				});
				$(".skill-progress4").progressAnimate({
					radius: 90,
					duration: 40,
					dataTo: 85,
					thickness: 14,
					circleBgColor : "#DFE8ED",
					circleFgColor : "#EB7D4C",
					lineCap: "butt",
					fontColor: "#FFFFFF",
					fontSize: "40px Titillium Web"
				});
				progressStart = false;
			}
		}
	});
	
	// Filtering
	jQuery(".portfolio-menu ul li a").click(function(){
		return false;
	});
	var filtering = document.querySelector("#mix-filtering");
	var mixer = mixitup(filtering);
	
	$('.owl-carousel').owlCarousel({
		autoplay: true,
		autoplayTimeout: 4000,
		items: 4,
		pagination: true,
		loop: true,
		responsive:{
			
			1200:{
				items: 4
			},
			1000:{
				items: 3
			},
			768:{
				items: 2
			},
			0:{
				items: 1
			}
		}
	});

	
	
	
	

});


